# 材料概论双语刷词 Android APK

离线双语材料概论词汇刷题应用。

## 自动生成 APK

仓库已包含 GitHub Actions。将本项目所有文件上传到 GitHub 仓库 `main` 分支后，会自动开始编译。

### 下载生成的 APK

1. 打开 GitHub 仓库。
2. 进入 **Actions**。
3. 打开最新一次 **Build Android APK**。
4. 等待绿色对勾。
5. 页面底部 **Artifacts** 中点击 `materials-vocab-apk`。
6. 下载压缩包并解压，得到 `材料概论双语刷词-v1.0.apk`。

也可以在 Actions 页面手动运行：**Build Android APK → Run workflow**。

## 本地构建

使用 Android Studio 打开项目，或在已配置 Android SDK 的环境运行：

```bash
gradle assembleDebug
```

APK 默认位于：

`app/build/outputs/apk/debug/app-debug.apk`
